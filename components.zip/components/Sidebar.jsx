"use client"
import { ChevronLeft, ChevronRight, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const SUBCATEGORIES_PER_PAGE = 12

export default function Sidebar({
  categories,
  selectedCategory,
  selectedSubcategory,
  setSelectedCategory,
  setSelectedSubcategory,
  setSearchTerm,
  currentPage,
  setCurrentPage,
  searchTerm,
}) {
  // Get all subcategories across all categories for pagination
  const getAllSubcategories = () => {
    const allSubs = []
    Object.entries(categories).forEach(([catKey, category]) => {
      // Add category header
      allSubs.push({
        type: "category",
        key: catKey,
        category: category,
        categoryKey: catKey,
      })

      // Add subcategories
      Object.entries(category.subcategories).forEach(([subKey, subcategory]) => {
        allSubs.push({
          type: "subcategory",
          key: subKey,
          subcategory: subcategory,
          categoryKey: catKey,
          subcategoryKey: subKey,
        })
      })
    })
    return allSubs
  }

  // Paginate all items
  const paginatedItems = () => {
    const allItems = getAllSubcategories()
    const startIndex = (currentPage - 1) * SUBCATEGORIES_PER_PAGE
    const endIndex = startIndex + SUBCATEGORIES_PER_PAGE
    return allItems.slice(startIndex, endIndex)
  }

  const totalPages = Math.ceil(getAllSubcategories().length / SUBCATEGORIES_PER_PAGE)

  const handleCategoryChange = (categoryKey) => {
    setSelectedCategory(categoryKey)
    const firstSubcategory = Object.keys(categories[categoryKey]?.subcategories || {})[0]
    if (firstSubcategory) {
      setSelectedSubcategory(firstSubcategory)
    }
    setSearchTerm("")
  }

  const handleSubcategoryChange = (categoryKey, subcategoryKey) => {
    setSelectedCategory(categoryKey)
    setSelectedSubcategory(subcategoryKey)
    setSearchTerm("")
  }

  return (
    <div className="w-80 bg-white shadow-lg border-r border-slate-200 flex flex-col">
      {/* Header with pagination controls */}
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-800">Medicine Categories</h2>
          <div className="flex items-center space-x-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="w-8 h-8 p-0 rounded-full border-slate-300 text-slate-600 hover:bg-slate-50"
            >
              <ChevronLeft className="w-3 h-3" />
            </Button>
            <span className="text-xs text-slate-500 px-2">
              {currentPage}/{totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="w-8 h-8 p-0 rounded-full border-slate-300 text-slate-600 hover:bg-slate-50"
            >
              <ChevronRight className="w-3 h-3" />
            </Button>
          </div>
        </div>
        <div className="mt-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-3 h-3" />
            <Input
              placeholder="Search medicines..."
              value={searchTerm || ""}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 h-8 text-xs rounded-lg border-slate-200 bg-white"
            />
          </div>
        </div>
      </div>

      {/* Categories and Subcategories List */}
      <div className="flex-1 overflow-hidden">
        <div className="space-y-1 p-2">
          {paginatedItems().map((item, index) => {
            if (item.type === "category") {
              return (
                <div
                  key={`cat-${item.key}`}
                  className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-all duration-200 ${
                    item.category.color || "bg-slate-100 text-slate-800"
                  } hover:opacity-80`}
                  onClick={() => handleCategoryChange(item.key)}
                >
                  <span className="text-lg">{item.category.icon}</span>
                  <span className={`font-medium ${item.category.color?.split(" ").find(c => c.startsWith("text-")) || "text-slate-800"}`}>{item.category.name}</span>
                </div>
              )
            } else {
              const isSelected = selectedCategory === item.categoryKey && selectedSubcategory === item.subcategoryKey
              const categoryColor = categories[item.categoryKey]?.color || "bg-slate-100 text-slate-800"

              return (
                <div
                  key={`sub-${item.categoryKey}-${item.key}`}
                  className={`ml-6 p-2 rounded-lg cursor-pointer transition-all duration-200 ${
                    isSelected
                      ? categoryColor.replace("100", "200") + " font-medium"
                      : "hover:bg-slate-50 text-slate-700"
                  }`}
                  onClick={() => handleSubcategoryChange(item.categoryKey, item.key)}
                >
                  <span className="text-sm">{item.subcategory.name}</span>
                </div>
              )
            }
          })}
        </div>
      </div>
    </div>
  )
}
