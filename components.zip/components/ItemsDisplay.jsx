"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function ItemsDisplay({ items, searchTerm, addToBill }) {
  // Filter items based on search term
  const filteredItems = searchTerm
    ? items.filter((item) => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
    : items

  return (
    <div className="flex-1 p-4 overflow-y-auto">
      {/* Search indicator */}
      {searchTerm && (
        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-sm text-blue-800">
            Searching for: "<strong>{searchTerm}</strong>" - Found {filteredItems.length} item(s)
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-2">
        {filteredItems.map((item) => (
          <Card
            key={item.id}
            className="rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer hover:scale-105 border border-slate-200 bg-white hover:bg-slate-50"
            onClick={() => addToBill(item)}
          >
            <CardContent className="p-2">
              <h3 className="font-semibold text-slate-800 mb-1 text-xs leading-tight truncate">{item.name}</h3>

              <div className="mb-1">
                <Badge className="bg-slate-200 text-slate-800 border-slate-300 rounded-full text-xs px-2 py-1 hover:bg-slate-300 hover:text-slate-900 transition-colors">
                  Stock: {item.stock}
                </Badge>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-slate-700">Rs {item.price}</span>
              </div>

              {searchTerm && (
                <div className="mt-1 text-xs text-slate-600 truncate">
                  {item.categoryName} → {item.subcategoryName}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <div className="text-slate-400 text-lg mb-2">
            {searchTerm ? `No items found for "${searchTerm}"` : "No items found"}
          </div>
          <div className="text-slate-500 text-sm">
            {searchTerm ? "Try searching with different keywords" : "Try adjusting your search or browse categories"}
          </div>
        </div>
      )}
    </div>
  )
}
