"use client"

import { useState } from "react"
import { Package, BarChart3, Edit3, Plus, Minus } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminDashboard({ open, onOpenChange, categories, updateInventory, getAllItems }) {
  const [adminTab, setAdminTab] = useState("inventory")

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto rounded-2xl">
        <DialogHeader>
          <DialogTitle>Admin Dashboard</DialogTitle>
        </DialogHeader>

        <Tabs value={adminTab} onValueChange={setAdminTab}>
          <TabsList className="grid w-full grid-cols-3 rounded-lg">
            <TabsTrigger value="inventory" className="rounded-lg">
              <Package className="w-4 h-4 mr-2" />
              Inventory
            </TabsTrigger>
            <TabsTrigger value="sales" className="rounded-lg">
              <BarChart3 className="w-4 h-4 mr-2" />
              Sales
            </TabsTrigger>
            <TabsTrigger value="edit" className="rounded-lg">
              <Edit3 className="w-4 h-4 mr-2" />
              Edit
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inventory" className="space-y-4">
            <h3 className="text-lg font-semibold">Inventory Management</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
              {getAllItems().map((item) => (
                <Card key={item.id} className="rounded-xl">
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-2">{item.name}</h4>
                    <div className="text-xs text-slate-500 mb-2">
                      {item.categoryName} → {item.subcategoryName}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateInventory(item.id, Math.max(0, item.stock - 1))}
                        className="rounded-lg"
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <span className="w-20 text-center font-medium">Stock: {item.stock}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateInventory(item.id, item.stock + 1)}
                        className="rounded-lg"
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="sales" className="space-y-4">
            <h3 className="text-lg font-semibold">Sales Analytics</h3>
            <div className="flex space-x-4 mb-4">
              <Select defaultValue="daily">
                <SelectTrigger className="w-32 rounded-lg">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="rounded-xl">
                <CardHeader>
                  <CardTitle>Total Sales</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">$12,450</div>
                  <p className="text-sm text-slate-500">This month</p>
                </CardContent>
              </Card>
              <Card className="rounded-xl">
                <CardHeader>
                  <CardTitle>Items Sold</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">1,234</div>
                  <p className="text-sm text-slate-500">This month</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="edit" className="space-y-4">
            <h3 className="text-lg font-semibold">Edit Items</h3>
            <div className="space-y-4">
              <Select>
                <SelectTrigger className="rounded-lg">
                  <SelectValue placeholder="Select what to edit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="category">Category</SelectItem>
                  <SelectItem value="subcategory">Subcategory</SelectItem>
                  <SelectItem value="item">Item</SelectItem>
                </SelectContent>
              </Select>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Name</Label>
                  <Input className="rounded-lg" />
                </div>
                <div>
                  <Label>Price</Label>
                  <Input type="number" className="rounded-lg" />
                </div>
              </div>

              <Button className="rounded-lg">Save Changes</Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
