"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function SearchDialog({ open, onOpenChange, categories, addToBill }) {
  const [searchTerm, setSearchTerm] = useState("")

  // Get all items for search
  const getAllItems = () => {
    const allItems = []
    Object.entries(categories).forEach(([catKey, category]) => {
      Object.entries(category.subcategories).forEach(([subKey, subcategory]) => {
        subcategory.items.forEach((item) => {
          allItems.push({
            ...item,
            categoryKey: catKey,
            subcategoryKey: subKey,
            categoryName: category.name,
            subcategoryName: subcategory.name,
          })
        })
      })
    })
    return allItems
  }

  // Filter items based on search
  const filteredItems = searchTerm
    ? getAllItems().filter((item) => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
    : []

  const handleItemClick = (item) => {
    addToBill(item)
    // Clear search and close dialog
    setSearchTerm("")
    onOpenChange(false)
  }

  const handleClose = () => {
    setSearchTerm("")
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
        <DialogHeader>
          <DialogTitle className="text-slate-800">Search Medicine</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Enter medicine name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 rounded-lg border-slate-200 bg-white"
              autoFocus
            />
          </div>

          <div className="max-h-96 overflow-y-auto">
            {searchTerm && filteredItems.length > 0 && (
              <div className="space-y-2">
                <div className="text-sm text-slate-600 mb-3">
                  Found {filteredItems.length} medicine(s) matching "{searchTerm}"
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {filteredItems.map((item) => (
                    <Card
                      key={item.id}
                      className="rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer hover:scale-105 border border-blue-200 bg-blue-50 hover:bg-blue-100"
                      onClick={() => handleItemClick(item)}
                    >
                      <CardContent className="p-3">
                        <h3 className="font-semibold text-blue-800 mb-2 text-sm">{item.name}</h3>

                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-bold text-blue-700">Rs {item.price}</span>
                          <Badge className="bg-slate-100 text-slate-700 border-slate-200 rounded-full text-xs px-2 py-1">
                            Stock: {item.stock}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {searchTerm && filteredItems.length === 0 && (
              <div className="text-center py-8">
                <div className="text-slate-400 text-lg mb-2">No medicines found</div>
                <div className="text-slate-500 text-sm">Try searching with a different name</div>
              </div>
            )}

            {!searchTerm && (
              <div className="text-center py-8">
                <div className="text-slate-400 text-lg mb-2">Start typing to search</div>
                <div className="text-slate-500 text-sm">Enter the name of the medicine you're looking for</div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
