"use client"

import { useState } from "react"
import { ArrowLeft, Plus, Minus } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function ReturnsDialog({ open, onOpenChange, categories, updateInventory }) {
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [selectedSubcategory, setSelectedSubcategory] = useState(null)
  const [selectedItem, setSelectedItem] = useState(null)
  const [returnQuantity, setReturnQuantity] = useState(1)

  const handleBack = () => {
    if (selectedItem) {
      setSelectedItem(null)
      setReturnQuantity(1)
    } else if (selectedSubcategory) {
      setSelectedSubcategory(null)
    } else if (selectedCategory) {
      setSelectedCategory(null)
    }
  }

  const handleCategoryClick = (categoryKey) => {
    setSelectedCategory(categoryKey)
  }

  const handleSubcategoryClick = (subcategoryKey) => {
    setSelectedSubcategory(subcategoryKey)
  }

  const handleItemClick = (item) => {
    setSelectedItem(item)
    setReturnQuantity(1)
  }

  const handleConfirmReturn = () => {
    if (selectedItem) {
      updateInventory(selectedItem.id, selectedItem.stock + returnQuantity)
      onOpenChange(false)
      setSelectedCategory(null)
      setSelectedSubcategory(null)
      setSelectedItem(null)
      setReturnQuantity(1)
    }
  }

  const getCurrentSubcategories = () => {
    if (selectedCategory) {
      return Object.entries(categories[selectedCategory]?.subcategories || {})
    }
    return []
  }

  const getCurrentItems = () => {
    if (selectedCategory && selectedSubcategory) {
      return categories[selectedCategory]?.subcategories[selectedSubcategory]?.items || []
    }
    return []
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl h-[80vh] rounded-lg border border-slate-200 bg-slate-50">
        <DialogHeader>
          <div className="flex items-center space-x-3">
            {(selectedCategory || selectedSubcategory || selectedItem) && (
              <Button variant="ghost" size="sm" onClick={handleBack} className="rounded-full">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            )}
            <DialogTitle className="text-slate-800">
              {selectedItem
                ? "Return Item - Confirm"
                : selectedSubcategory
                  ? `Return Item - Select ${categories[selectedCategory]?.name} Item`
                  : selectedCategory
                    ? `Return Item - Select ${categories[selectedCategory]?.name} Subcategory`
                    : "Return Item - Select Category"}
            </DialogTitle>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          {/* Categories */}
          {!selectedCategory && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(categories).map(([key, category]) => (
                <Card
                  key={key}
                  className="rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer border border-slate-200 bg-white hover:bg-slate-50"
                  onClick={() => handleCategoryClick(key)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center border border-slate-200">
                        <span className="text-lg">{category.icon}</span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-800">{category.name}</h3>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Subcategories */}
          {selectedCategory && !selectedSubcategory && !selectedItem && (
            <div className="space-y-3">
              {getCurrentSubcategories().map(([subKey, subcategory]) => (
                <Button
                  key={subKey}
                  variant="outline"
                  className="w-full justify-start rounded-lg h-auto p-4 border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-800"
                  onClick={() => handleSubcategoryClick(subKey)}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-blue-100 border border-blue-200">
                      <span className="text-sm">{subcategory.icon || "💊"}</span>
                    </div>
                    <span className="font-medium">{subcategory.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          )}

          {/* Items */}
          {selectedCategory && selectedSubcategory && !selectedItem && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {getCurrentItems().map((item) => (
                <Card
                  key={item.id}
                  className="rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer border border-slate-200 bg-white hover:bg-slate-50"
                  onClick={() => handleItemClick(item)}
                >
                  <CardContent className="p-2">
                    <h3 className="font-semibold text-slate-800 mb-1 text-xs">{item.name}</h3>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs font-medium text-slate-600">Stock: {item.stock}</span>
                      <span className="text-sm font-bold text-slate-700">Rs {item.price}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Confirm Return */}
          {selectedItem && (
            <div className="space-y-6">
              <Card className="rounded-lg border border-slate-200 bg-white">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4 text-slate-800">{selectedItem.name}</h3>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <div className="text-sm text-slate-600">Category:</div>
                      <div className="font-medium text-slate-800">{categories[selectedCategory]?.name}</div>
                    </div>
                    <div>
                      <div className="text-sm text-slate-600">Subcategory:</div>
                      <div className="font-medium text-slate-800">
                        {categories[selectedCategory]?.subcategories[selectedSubcategory]?.name}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-slate-600">Price:</div>
                      <div className="font-medium text-slate-800">Rs {selectedItem.price}</div>
                    </div>
                    <div>
                      <div className="text-sm text-slate-600">Current Stock:</div>
                      <div className="font-medium text-slate-800">{selectedItem.stock}</div>
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="text-sm text-slate-600 mb-2">Return Quantity:</div>
                    <div className="flex items-center space-x-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setReturnQuantity(Math.max(1, returnQuantity - 1))}
                        className="rounded-full border-red-300 text-red-600 hover:bg-red-100"
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span className="w-12 text-center font-medium text-lg text-slate-800">{returnQuantity}</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setReturnQuantity(returnQuantity + 1)}
                        className="rounded-full border-blue-300 text-blue-600 hover:bg-blue-100"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-6">
                    <div className="text-sm text-blue-800">
                      After return, the stock will be updated to: <strong>{selectedItem.stock + returnQuantity}</strong>
                    </div>
                  </div>

                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      onClick={handleBack}
                      className="flex-1 rounded-lg border-red-300 text-red-600 hover:bg-red-50"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleConfirmReturn}
                      className="flex-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Confirm Return
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
