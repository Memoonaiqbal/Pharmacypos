"use client"

import { useState } from "react"
import {
  LayoutDashboard,
  Package,
  BarChart3,
  Edit3,
  LogOut,
  Plus,
  Minus,
  Search,
  Trash2,
  Save,
  DollarSign,
  ShoppingCart,
  TrendingUp,
  AlertTriangle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminModule({ categories, setCategories, updateInventory, getAllItems, onLogout }) {
  const [activeSection, setActiveSection] = useState("dashboard")
  const [salesPeriod, setSalesPeriod] = useState("daily")
  const [searchTerm, setSearchTerm] = useState("")
  const [editMode, setEditMode] = useState("categories")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedSubcategory, setSelectedSubcategory] = useState("")
  const [inventoryCategory, setInventoryCategory] = useState("")
  const [inventorySubcategory, setInventorySubcategory] = useState("")
  const [chartType, setChartType] = useState("bar")

  // Form states for adding new items
  const [newCategory, setNewCategory] = useState({ name: "" })
  const [newSubcategory, setNewSubcategory] = useState({ name: "" })
  const [newItem, setNewItem] = useState({ name: "", price: "", stock: "" })
  const [showAddCategoryDialog, setShowAddCategoryDialog] = useState(false)
  const [showAddSubcategoryDialog, setShowAddSubcategoryDialog] = useState(false)
  const [showAddItemDialog, setShowAddItemDialog] = useState(false)

  // Edit states
  const [editingItem, setEditingItem] = useState(null)
  const [showEditItemDialog, setShowEditItemDialog] = useState(false)
  const [editItemData, setEditItemData] = useState({ name: "", price: "", stock: "" })

  // Edit category states
  const [editingCategory, setEditingCategory] = useState(null)
  const [showEditCategoryDialog, setShowEditCategoryDialog] = useState(false)
  const [editCategoryData, setEditCategoryData] = useState({ name: "" })

  // Edit subcategory states
  const [editingSubcategory, setEditingSubcategory] = useState(null)
  const [showEditSubcategoryDialog, setShowEditSubcategoryDialog] = useState(false)
  const [editSubcategoryData, setEditSubcategoryData] = useState({ name: "" })

  // Predefined emojis for auto-assignment
  const categoryEmojis = ["💊", "🍊", "🩸", "🤒", "🫃", "❤️", "🧬", "⚡", "🌿", "🔬"]

  // Sample sales data
  const salesData = {
    daily: {
      totalSales: 1250.5,
      itemsSold: 45,
      customers: 12,
      avgOrder: 104.21,
      chartData: [
        { time: "9 AM", sales: 120 },
        { time: "10 AM", sales: 180 },
        { time: "11 AM", sales: 250 },
        { time: "12 PM", sales: 320 },
        { time: "1 PM", sales: 280 },
        { time: "2 PM", sales: 200 },
        { time: "3 PM", sales: 150 },
      ],
    },
    monthly: {
      totalSales: 35420.75,
      itemsSold: 1234,
      customers: 456,
      avgOrder: 77.68,
      chartData: [
        { time: "Week 1", sales: 8500 },
        { time: "Week 2", sales: 9200 },
        { time: "Week 3", sales: 8800 },
        { time: "Week 4", sales: 8920 },
      ],
    },
    yearly: {
      totalSales: 425049.0,
      itemsSold: 15678,
      customers: 2345,
      avgOrder: 181.25,
      chartData: [
        { time: "Jan", sales: 32000 },
        { time: "Feb", sales: 28000 },
        { time: "Mar", sales: 35000 },
        { time: "Apr", sales: 38000 },
        { time: "May", sales: 42000 },
        { time: "Jun", sales: 39000 },
      ],
    },
  }

  const currentSalesData = salesData[salesPeriod]

  const sidebarItems = [
    { id: "dashboard", label: "Admin Dashboard", icon: LayoutDashboard },
    { id: "inventory", label: "Inventory", icon: Package },
    { id: "sales", label: "Sales", icon: BarChart3 },
    { id: "edit", label: "Edit", icon: Edit3 },
  ]

  // Add functions
  const handleAddCategory = () => {
    if (newCategory.name) {
      const categoryKey = newCategory.name.toLowerCase().replace(/\s+/g, "")
      const existingCategories = Object.keys(categories)
      const emojiIndex = existingCategories.length % categoryEmojis.length

      const colorClass = "bg-blue-100 text-blue-800 border-blue-200"

      setCategories((prev) => ({
        ...prev,
        [categoryKey]: {
          name: newCategory.name,
          icon: categoryEmojis[emojiIndex],
          color: colorClass,
          subcategories: {},
        },
      }))

      setNewCategory({ name: "" })
      setShowAddCategoryDialog(false)
    }
  }

  const handleAddSubcategory = () => {
    if (newSubcategory.name && selectedCategory) {
      const subcategoryKey = newSubcategory.name.toLowerCase().replace(/\s+/g, "")

      setCategories((prev) => ({
        ...prev,
        [selectedCategory]: {
          ...prev[selectedCategory],
          subcategories: {
            ...prev[selectedCategory].subcategories,
            [subcategoryKey]: {
              name: newSubcategory.name,
              icon: "💊",
              items: [],
            },
          },
        },
      }))

      setNewSubcategory({ name: "" })
      setShowAddSubcategoryDialog(false)
    }
  }

  const handleAddItem = () => {
    if (newItem.name && newItem.price && newItem.stock && selectedCategory && selectedSubcategory) {
      const allItems = getAllItems()
      const newId = allItems.length > 0 ? Math.max(...allItems.map((item) => item.id)) + 1 : 1

      setCategories((prev) => ({
        ...prev,
        [selectedCategory]: {
          ...prev[selectedCategory],
          subcategories: {
            ...prev[selectedCategory].subcategories,
            [selectedSubcategory]: {
              ...prev[selectedCategory].subcategories[selectedSubcategory],
              items: [
                ...prev[selectedCategory].subcategories[selectedSubcategory].items,
                {
                  id: newId,
                  code: `ITM${newId.toString().padStart(3, "0")}`,
                  name: newItem.name,
                  price: Number.parseFloat(newItem.price),
                  stock: Number.parseInt(newItem.stock),
                },
              ],
            },
          },
        },
      }))

      setNewItem({ name: "", price: "", stock: "" })
      setShowAddItemDialog(false)
    }
  }

  // Edit functions
  const handleEditItem = (item) => {
    setEditingItem(item)
    setEditItemData({
      name: item.name,
      price: item.price.toString(),
      stock: item.stock.toString(),
    })
    setShowEditItemDialog(true)
  }

  const handleSaveEditItem = () => {
    if (editingItem && editItemData.name && editItemData.price && editItemData.stock) {
      setCategories((prev) => {
        const newCategories = { ...prev }
        Object.keys(newCategories).forEach((catKey) => {
          Object.keys(newCategories[catKey].subcategories).forEach((subKey) => {
            newCategories[catKey].subcategories[subKey].items = newCategories[catKey].subcategories[subKey].items.map(
              (item) =>
                item.id === editingItem.id
                  ? {
                      ...item,
                      name: editItemData.name,
                      price: Number.parseFloat(editItemData.price),
                      stock: Number.parseInt(editItemData.stock),
                    }
                  : item,
            )
          })
        })
        return newCategories
      })

      setEditingItem(null)
      setEditItemData({ name: "", price: "", stock: "" })
      setShowEditItemDialog(false)
    }
  }

  // Edit category functions
  const handleEditCategory = (categoryKey, category) => {
    setEditingCategory({ key: categoryKey, ...category })
    setEditCategoryData({ name: category.name })
    setShowEditCategoryDialog(true)
  }

  const handleSaveEditCategory = () => {
    if (editingCategory && editCategoryData.name) {
      setCategories((prev) => ({
        ...prev,
        [editingCategory.key]: {
          ...prev[editingCategory.key],
          name: editCategoryData.name,
        },
      }))

      setEditingCategory(null)
      setEditCategoryData({ name: "" })
      setShowEditCategoryDialog(false)
    }
  }

  // Edit subcategory functions
  const handleEditSubcategory = (categoryKey, subcategoryKey, subcategory) => {
    setEditingSubcategory({ categoryKey, subcategoryKey, ...subcategory })
    setEditSubcategoryData({ name: subcategory.name })
    setShowEditSubcategoryDialog(true)
  }

  const handleSaveEditSubcategory = () => {
    if (editingSubcategory && editSubcategoryData.name) {
      setCategories((prev) => ({
        ...prev,
        [editingSubcategory.categoryKey]: {
          ...prev[editingSubcategory.categoryKey],
          subcategories: {
            ...prev[editingSubcategory.categoryKey].subcategories,
            [editingSubcategory.subcategoryKey]: {
              ...prev[editingSubcategory.categoryKey].subcategories[editingSubcategory.subcategoryKey],
              name: editSubcategoryData.name,
            },
          },
        },
      }))

      setEditingSubcategory(null)
      setEditSubcategoryData({ name: "" })
      setShowEditSubcategoryDialog(false)
    }
  }

  // Delete functions - NO confirmation messages
  const handleDeleteCategory = (categoryKey) => {
    setCategories((prev) => {
      const newCategories = { ...prev }
      delete newCategories[categoryKey]
      return newCategories
    })
  }

  const handleDeleteSubcategory = (categoryKey, subcategoryKey) => {
    setCategories((prev) => ({
      ...prev,
      [categoryKey]: {
        ...prev[categoryKey],
        subcategories: Object.fromEntries(
          Object.entries(prev[categoryKey].subcategories).filter(([key]) => key !== subcategoryKey),
        ),
      },
    }))
  }

  const handleDeleteItem = (itemId) => {
    setCategories((prev) => {
      const newCategories = { ...prev }
      Object.keys(newCategories).forEach((catKey) => {
        Object.keys(newCategories[catKey].subcategories).forEach((subKey) => {
          newCategories[catKey].subcategories[subKey].items = newCategories[catKey].subcategories[subKey].items.filter(
            (item) => item.id !== itemId,
          )
        })
      })
      return newCategories
    })
  }

  const renderDashboard = () => (
    <div className="space-y-4">
      <div className="bg-slate-100 rounded-lg p-4 border border-slate-200">
        <h1 className="text-2xl font-bold mb-1 text-slate-800">Admin Dashboard</h1>
        <p className="text-slate-600">Welcome to Remidix Pharmacy Admin Panel</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="rounded-lg border border-blue-200 bg-blue-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Total Sales Today</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700">Rs {currentSalesData.totalSales}</div>
            <p className="text-xs text-blue-600">+12% from yesterday</p>
          </CardContent>
        </Card>

        <Card className="rounded-lg border border-slate-200 bg-slate-50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-800">Items Sold</CardTitle>
            <ShoppingCart className="h-4 w-4 text-slate-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-700">{currentSalesData.itemsSold}</div>
            <p className="text-xs text-slate-600">+8% from yesterday</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="rounded-lg border border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-800">
              <AlertTriangle className="w-4 h-4" />
              <span>Low Stock Alert</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {getAllItems()
                .filter((item) => item.stock < 30)
                .slice(0, 5)
                .map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 bg-red-100 rounded-lg border border-red-200"
                  >
                    <span className="text-sm font-medium text-red-800">{item.name}</span>
                    <Badge className="bg-red-200 text-red-800 border-red-300 text-xs">Stock: {item.stock}</Badge>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-lg border border-slate-200 bg-slate-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-slate-800">
              <TrendingUp className="w-4 h-4" />
              <span>Sales Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center p-2 bg-slate-100 rounded-lg border border-slate-200">
                <span className="text-sm font-medium text-slate-800">Total Sales</span>
                <span className="text-slate-700 font-bold">Rs {currentSalesData.totalSales}</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-slate-100 rounded-lg border border-slate-200">
                <span className="text-sm font-medium text-slate-800">Items Sold</span>
                <span className="text-slate-700 font-bold">{currentSalesData.itemsSold}</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-slate-100 rounded-lg border border-slate-200">
                <span className="text-sm font-medium text-slate-800">Customers</span>
                <span className="text-slate-700 font-bold">{currentSalesData.customers}</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-slate-100 rounded-lg border border-slate-200">
                <span className="text-sm font-medium text-slate-800">Average Order</span>
                <span className="text-slate-700 font-bold">Rs {currentSalesData.avgOrder}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const renderInventory = () => {
    const getInventoryItems = () => {
      if (!inventoryCategory || !inventorySubcategory) return []
      return categories[inventoryCategory]?.subcategories[inventorySubcategory]?.items || []
    }

    // Reset subcategory when category changes
    const handleInventoryCategoryChange = (categoryKey) => {
      setInventoryCategory(categoryKey)
      setInventorySubcategory("") // Reset subcategory when category changes
    }

    return (
      <div className="space-y-4">
        <div className="bg-slate-100 rounded-lg p-4 border border-slate-200">
          <h1 className="text-2xl font-bold mb-1 text-slate-800">Inventory Management</h1>
          <p className="text-slate-600">Select category and subcategory to manage inventory</p>
        </div>

        <div className="flex items-center space-x-4">
          <Select value={inventoryCategory} onValueChange={handleInventoryCategoryChange}>
            <SelectTrigger className="w-48 rounded-lg border-blue-200 bg-blue-50">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(categories).map(([key, category]) => (
                <SelectItem key={key} value={key}>
                  {category.icon} {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {inventoryCategory && (
            <Select value={inventorySubcategory} onValueChange={setInventorySubcategory}>
              <SelectTrigger className="w-48 rounded-lg border-blue-200 bg-blue-50">
                <SelectValue placeholder="Select subcategory" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(categories[inventoryCategory]?.subcategories || {}).map(([key, subcategory]) => (
                  <SelectItem key={key} value={key}>
                    {subcategory.icon} {subcategory.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {inventoryCategory && inventorySubcategory && (
          <Card className="rounded-lg border border-blue-200 bg-blue-50">
            <CardHeader className="bg-blue-100 border-b border-blue-200">
              <CardTitle className="flex items-center space-x-3 text-blue-800">
                <span className="text-lg">{categories[inventoryCategory]?.icon}</span>
                <span>{categories[inventoryCategory]?.name}</span>
                <span>→</span>
                <span>{categories[inventoryCategory]?.subcategories[inventorySubcategory]?.name}</span>
                <Badge className="ml-auto bg-blue-200 text-blue-800 border-blue-300">
                  {getInventoryItems().length} items
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
                {getInventoryItems().map((item) => (
                  <Card key={item.id} className="rounded-lg border border-slate-200 bg-white">
                    <CardContent className="p-2">
                      <h4 className="font-medium text-xs mb-1 truncate text-slate-800">{item.name}</h4>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-slate-700 font-medium">Rs {item.price}</span>
                        <Badge
                          className={`text-xs px-1 py-0 ${
                            item.stock < 30
                              ? "bg-red-200 text-red-800 border-red-300"
                              : "bg-slate-200 text-slate-800 border-slate-300"
                          }`}
                        >
                          {item.stock}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateInventory(item.id, Math.max(0, item.stock - 1))}
                          className="rounded-md h-5 w-5 p-0 border-red-300 text-red-600 hover:bg-red-100"
                        >
                          <Minus className="w-2 h-2" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateInventory(item.id, item.stock + 10)}
                          className="rounded-md h-5 w-5 p-0 border-blue-300 text-blue-600 hover:bg-blue-100"
                        >
                          <Plus className="w-2 h-2" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    )
  }

  const renderSales = () => {
    const renderChart = () => {
      const colors = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899"]
      const maxValue = Math.max(...currentSalesData.chartData.map((d) => d.sales))

      switch (chartType) {
        case "bar":
          return (
            <div className="space-y-4">
              <div className="h-64 flex items-end justify-between space-x-2 bg-white p-4 rounded-lg border">
                {currentSalesData.chartData.map((data, index) => (
                  <div key={index} className="flex flex-col items-center space-y-2 flex-1 group">
                    <div className="text-xs font-medium text-slate-700 mb-1">Rs {data.sales}</div>
                    <div
                      className="rounded-t-lg w-full transition-all duration-500 hover:opacity-80 cursor-pointer shadow-sm"
                      style={{
                        height: `${(data.sales / maxValue) * 180}px`,
                        backgroundColor: colors[index % colors.length],
                        minHeight: "20px",
                      }}
                    ></div>
                    <span className="text-xs text-slate-600 font-medium">{data.time}</span>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {currentSalesData.chartData.map((data, index) => (
                  <div key={index} className="flex items-center space-x-2 text-xs">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: colors[index % colors.length] }}
                    ></div>
                    <span className="text-slate-600">
                      {data.time}: Rs {data.sales}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )
        case "line":
          return (
            <div className="space-y-4">
              <div className="h-64 relative bg-white p-4 rounded-lg border">
                <svg className="w-full h-full">
                  {/* Grid lines */}
                  <defs>
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#f1f5f9" strokeWidth="1" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid)" />

                  {/* Area under line */}
                  <defs>
                    <linearGradient id="lineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.05" />
                    </linearGradient>
                  </defs>
                  <polygon
                    fill="url(#lineGradient)"
                    points={`0,100% ${currentSalesData.chartData
                      .map((data, index) => {
                        const x = (index / (currentSalesData.chartData.length - 1)) * 100
                        const y = 100 - (data.sales / maxValue) * 80
                        return `${x}%,${y}%`
                      })
                      .join(" ")} 100%,100%`}
                  />

                  {/* Main line */}
                  <polyline
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={currentSalesData.chartData
                      .map((data, index) => {
                        const x = (index / (currentSalesData.chartData.length - 1)) * 100
                        const y = 100 - (data.sales / maxValue) * 80
                        return `${x}%,${y}%`
                      })
                      .join(" ")}
                  />

                  {/* Data points */}
                  {currentSalesData.chartData.map((data, index) => {
                    const x = (index / (currentSalesData.chartData.length - 1)) * 100
                    const y = 100 - (data.sales / maxValue) * 80
                    return (
                      <g key={index}>
                        <circle
                          cx={`${x}%`}
                          cy={`${y}%`}
                          r="5"
                          fill="white"
                          stroke="#3b82f6"
                          strokeWidth="3"
                          className="hover:r-7 transition-all cursor-pointer"
                        />
                        <text
                          x={`${x}%`}
                          y={`${y - 10}%`}
                          textAnchor="middle"
                          className="text-xs fill-slate-600 font-medium"
                        >
                          Rs {data.sales}
                        </text>
                      </g>
                    )
                  })}
                </svg>
                <div className="absolute bottom-0 left-4 right-4 flex justify-between text-xs text-slate-600 font-medium">
                  {currentSalesData.chartData.map((data, index) => (
                    <span key={index}>{data.time}</span>
                  ))}
                </div>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                <div className="text-sm font-medium text-blue-800 mb-1">Trend Analysis</div>
                <div className="text-xs text-blue-600">
                  Peak: Rs {Math.max(...currentSalesData.chartData.map((d) => d.sales))} | Average: Rs{" "}
                  {(
                    currentSalesData.chartData.reduce((sum, d) => sum + d.sales, 0) / currentSalesData.chartData.length
                  ).toFixed(0)}{" "}
                  | Growth: +
                  {(
                    (currentSalesData.chartData[currentSalesData.chartData.length - 1].sales /
                      currentSalesData.chartData[0].sales -
                      1) *
                    100
                  ).toFixed(1)}
                  %
                </div>
              </div>
            </div>
          )
        case "pie":
          const total = currentSalesData.chartData.reduce((sum, data) => sum + data.sales, 0)
          let cumulativePercentage = 0
          return (
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="relative">
                  <svg className="w-64 h-64">
                    {/* Shadow */}
                    <circle cx="132" cy="132" r="80" fill="rgba(0,0,0,0.1)" />

                    {currentSalesData.chartData.map((data, index) => {
                      const percentage = (data.sales / total) * 100
                      const startAngle = (cumulativePercentage / 100) * 360 - 90
                      const endAngle = ((cumulativePercentage + percentage) / 100) * 360 - 90
                      cumulativePercentage += percentage

                      const startAngleRad = (startAngle * Math.PI) / 180
                      const endAngleRad = (endAngle * Math.PI) / 180

                      const largeArcFlag = percentage > 50 ? 1 : 0
                      const x1 = 128 + 80 * Math.cos(startAngleRad)
                      const y1 = 128 + 80 * Math.sin(startAngleRad)
                      const x2 = 128 + 80 * Math.cos(endAngleRad)
                      const y2 = 128 + 80 * Math.sin(endAngleRad)

                      const pathData = [
                        `M 128 128`,
                        `L ${x1} ${y1}`,
                        `A 80 80 0 ${largeArcFlag} 1 ${x2} ${y2}`,
                        `Z`,
                      ].join(" ")

                      // Label position
                      const labelAngle = (startAngle + endAngle) / 2
                      const labelAngleRad = (labelAngle * Math.PI) / 180
                      const labelX = 128 + 100 * Math.cos(labelAngleRad)
                      const labelY = 128 + 100 * Math.sin(labelAngleRad)

                      return (
                        <g key={index}>
                          <path
                            d={pathData}
                            fill={colors[index % colors.length]}
                            stroke="white"
                            strokeWidth="2"
                            className="hover:opacity-80 transition-opacity cursor-pointer"
                            style={{
                              filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.1))",
                            }}
                          />
                          {percentage > 5 && (
                            <text
                              x={labelX}
                              y={labelY}
                              textAnchor="middle"
                              dominantBaseline="middle"
                              className="text-xs font-medium fill-slate-700"
                            >
                              {percentage.toFixed(1)}%
                            </text>
                          )}
                        </g>
                      )
                    })}

                    {/* Center circle with total */}
                    <circle cx="128" cy="128" r="35" fill="white" stroke="#e2e8f0" strokeWidth="2" />
                    <text x="128" y="120" textAnchor="middle" className="text-xs font-medium fill-slate-600">
                      Total Sales
                    </text>
                    <text x="128" y="135" textAnchor="middle" className="text-sm font-bold fill-slate-800">
                      Rs {total}
                    </text>
                  </svg>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {currentSalesData.chartData.map((data, index) => {
                  const percentage = (data.sales / total) * 100
                  return (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-white rounded-lg border">
                      <div
                        className="w-4 h-4 rounded-full flex-shrink-0"
                        style={{ backgroundColor: colors[index % colors.length] }}
                      ></div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-slate-800 truncate">{data.time}</div>
                        <div className="text-xs text-slate-600">
                          Rs {data.sales} ({percentage.toFixed(1)}%)
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        case "area":
          return (
            <div className="space-y-4">
              <div className="h-64 relative bg-white p-4 rounded-lg border">
                <svg className="w-full h-full">
                  {/* Grid */}
                  <defs>
                    <pattern id="areaGrid" width="50" height="50" patternUnits="userSpaceOnUse">
                      <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#f8fafc" strokeWidth="1" />
                    </pattern>
                    <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.6" />
                      <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.1" />
                    </linearGradient>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#areaGrid)" />

                  {/* Area */}
                  <polygon
                    fill="url(#areaGradient)"
                    points={`0,100% ${currentSalesData.chartData
                      .map((data, index) => {
                        const x = (index / (currentSalesData.chartData.length - 1)) * 100
                        const y = 100 - (data.sales / maxValue) * 80
                        return `${x}%,${y}%`
                      })
                      .join(" ")} 100%,100%`}
                  />

                  {/* Top line */}
                  <polyline
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="3"
                    strokeLinecap="round"
                    points={currentSalesData.chartData
                      .map((data, index) => {
                        const x = (index / (currentSalesData.chartData.length - 1)) * 100
                        const y = 100 - (data.sales / maxValue) * 80
                        return `${x}%,${y}%`
                      })
                      .join(" ")}
                  />

                  {/* Data points with values */}
                  {currentSalesData.chartData.map((data, index) => {
                    const x = (index / (currentSalesData.chartData.length - 1)) * 100
                    const y = 100 - (data.sales / maxValue) * 80
                    return (
                      <g key={index}>
                        <circle
                          cx={`${x}%`}
                          cy={`${y}%`}
                          r="4"
                          fill="#3b82f6"
                          stroke="white"
                          strokeWidth="2"
                          className="hover:r-6 transition-all cursor-pointer"
                        />
                        <rect
                          x={`${x - 15}%`}
                          y={`${y - 25}%`}
                          width="30"
                          height="16"
                          rx="8"
                          fill="rgba(59, 130, 246, 0.9)"
                          className="opacity-0 hover:opacity-100 transition-opacity"
                        />
                        <text
                          x={`${x}%`}
                          y={`${y - 15}%`}
                          textAnchor="middle"
                          className="text-xs fill-white font-medium opacity-0 hover:opacity-100 transition-opacity"
                        >
                          Rs {data.sales}
                        </text>
                      </g>
                    )
                  })}
                </svg>
                <div className="absolute bottom-0 left-4 right-4 flex justify-between text-xs text-slate-600 font-medium">
                  {currentSalesData.chartData.map((data, index) => (
                    <span key={index}>{data.time}</span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 text-center">
                  <div className="text-lg font-bold text-blue-700">
                    Rs {Math.max(...currentSalesData.chartData.map((d) => d.sales))}
                  </div>
                  <div className="text-xs text-blue-600">Peak Sales</div>
                </div>
                <div className="bg-green-50 p-3 rounded-lg border border-green-200 text-center">
                  <div className="text-lg font-bold text-green-700">
                    Rs{" "}
                    {(
                      currentSalesData.chartData.reduce((sum, d) => sum + d.sales, 0) /
                      currentSalesData.chartData.length
                    ).toFixed(0)}
                  </div>
                  <div className="text-xs text-green-600">Average</div>
                </div>
                <div className="bg-purple-50 p-3 rounded-lg border border-purple-200 text-center">
                  <div className="text-lg font-bold text-purple-700">
                    Rs {currentSalesData.chartData.reduce((sum, d) => sum + d.sales, 0)}
                  </div>
                  <div className="text-xs text-purple-600">Total</div>
                </div>
              </div>
            </div>
          )
        default:
          return <div className="h-64 flex items-center justify-center text-slate-500">Select a chart type</div>
      }
    }

    return (
      <div className="space-y-4">
        <div className="bg-slate-100 rounded-lg p-4 border border-slate-200">
          <h1 className="text-2xl font-bold mb-1 text-slate-800">Sales Analytics</h1>
          <p className="text-slate-600">Track sales performance and trends with detailed insights</p>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Select value={chartType} onValueChange={setChartType}>
              <SelectTrigger className="w-40 rounded-lg border-blue-200 bg-blue-50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bar">📊 Bar Chart</SelectItem>
                <SelectItem value="line">📈 Line Chart</SelectItem>
                <SelectItem value="pie">🥧 Pie Chart</SelectItem>
                <SelectItem value="area">📉 Area Chart</SelectItem>
              </SelectContent>
            </Select>
            <Select value={salesPeriod} onValueChange={setSalesPeriod}>
              <SelectTrigger className="w-32 rounded-lg border-blue-200 bg-blue-50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">📅 Daily</SelectItem>
                <SelectItem value="monthly">📆 Monthly</SelectItem>
                <SelectItem value="yearly">🗓️ Yearly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="text-sm text-slate-600">Showing {salesPeriod} sales data</div>
        </div>

        <Card className="rounded-lg border border-blue-200 bg-blue-50">
          <CardHeader className="bg-blue-100 border-b border-blue-200">
            <CardTitle className="flex items-center justify-between text-blue-800">
              <span>Sales Chart - {salesPeriod.charAt(0).toUpperCase() + salesPeriod.slice(1)}</span>
              <Badge className="bg-blue-200 text-blue-800 border-blue-300">
                {chartType.charAt(0).toUpperCase() + chartType.slice(1)} Chart
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">{renderChart()}</CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="rounded-lg border border-slate-200 bg-slate-50">
            <CardHeader className="bg-slate-100 border-b border-slate-200">
              <CardTitle className="text-slate-800">Sales by Category</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-2">
                {Object.entries(categories).map(([key, category], index) => {
                  const randomSales = (Math.random() * 5000 + 1000).toFixed(2)
                  const percentage = ((randomSales / 25000) * 100).toFixed(1)
                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between p-3 bg-white rounded-lg border border-slate-200 hover:shadow-sm transition-shadow"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-lg">{category.icon}</span>
                        <div>
                          <span className="text-sm font-medium text-slate-800">{category.name}</span>
                          <div className="text-xs text-slate-500">{percentage}% of total sales</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-slate-700 font-bold">Rs {randomSales}</div>
                        <div className="text-xs text-green-600">+{(Math.random() * 20 + 5).toFixed(1)}%</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-lg border border-slate-200 bg-slate-50">
            <CardHeader className="bg-slate-100 border-b border-slate-200">
              <CardTitle className="text-slate-800">Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                    <div className="text-lg font-bold text-green-700">Rs {currentSalesData.totalSales}</div>
                    <div className="text-xs text-green-600">Total Revenue</div>
                  </div>
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <div className="text-lg font-bold text-blue-700">{currentSalesData.itemsSold}</div>
                    <div className="text-xs text-blue-600">Items Sold</div>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                    <div className="text-lg font-bold text-purple-700">{currentSalesData.customers}</div>
                    <div className="text-xs text-purple-600">Customers</div>
                  </div>
                  <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                    <div className="text-lg font-bold text-orange-700">Rs {currentSalesData.avgOrder}</div>
                    <div className="text-xs text-orange-600">Avg Order</div>
                  </div>
                </div>

                <div className="bg-slate-100 p-3 rounded-lg border border-slate-200">
                  <div className="text-sm font-medium text-slate-800 mb-2">Sales Trend</div>
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: "75%" }}
                      ></div>
                    </div>
                    <span className="text-xs text-slate-600 font-medium">75% to target</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const renderEdit = () => (
    <div className="space-y-4">
      <div className="bg-slate-100 rounded-lg p-4 border border-slate-200">
        <h1 className="text-2xl font-bold mb-1 text-slate-800">Edit Management</h1>
        <p className="text-slate-600">Add, edit, or delete categories, subcategories, and items</p>
      </div>

      <Tabs value={editMode} onValueChange={setEditMode}>
        <TabsList className="grid w-full grid-cols-3 rounded-lg bg-blue-50 border border-blue-200">
          <TabsTrigger
            value="categories"
            className="rounded-lg data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800"
          >
            Categories
          </TabsTrigger>
          <TabsTrigger
            value="subcategories"
            className="rounded-lg data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800"
          >
            Subcategories
          </TabsTrigger>
          <TabsTrigger
            value="items"
            className="rounded-lg data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800"
          >
            Items
          </TabsTrigger>
        </TabsList>

        <TabsContent value="categories" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">Manage Categories</h3>
            <Dialog open={showAddCategoryDialog} onOpenChange={setShowAddCategoryDialog}>
              <DialogTrigger asChild>
                <Button className="rounded-lg bg-blue-600 hover:bg-blue-700 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent className="rounded-lg border border-blue-200 bg-blue-50">
                <DialogHeader>
                  <DialogTitle className="text-blue-800">Add New Category</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label className="text-blue-700">Category Name</Label>
                    <Input
                      className="rounded-lg border-blue-200 bg-white"
                      placeholder="Enter category name"
                      value={newCategory.name}
                      onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    />
                  </div>
                  <Button
                    onClick={handleAddCategory}
                    className="w-full rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Category
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(categories).map(([key, category]) => (
              <Card key={key} className="rounded-lg border border-slate-200 bg-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">{category.icon}</span>
                      <span className="font-medium text-slate-800">{category.name}</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="rounded-lg border-red-300 text-red-600 hover:bg-red-100"
                      onClick={() => handleDeleteCategory(key)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="text-xs text-slate-600 mb-3 bg-slate-100 p-2 rounded border border-slate-200">
                    {Object.keys(category.subcategories).length} subcategories
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full rounded-lg border-slate-300 text-slate-600 hover:bg-slate-100"
                    onClick={() => handleEditCategory(key, category)}
                  >
                    Edit Category
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="subcategories" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">Manage Subcategories</h3>
            <div className="flex items-center space-x-3">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48 rounded-lg border-blue-200 bg-blue-50">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(categories).map(([key, category]) => (
                    <SelectItem key={key} value={key}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Dialog open={showAddSubcategoryDialog} onOpenChange={setShowAddSubcategoryDialog}>
                <DialogTrigger asChild>
                  <Button className="rounded-lg bg-blue-600 hover:bg-blue-700 text-white" disabled={!selectedCategory}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Subcategory
                  </Button>
                </DialogTrigger>
                <DialogContent className="rounded-lg border border-blue-200 bg-blue-50">
                  <DialogHeader>
                    <DialogTitle className="text-blue-800">Add New Subcategory</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-blue-700">Subcategory Name</Label>
                      <Input
                        className="rounded-lg border-blue-200 bg-white"
                        placeholder="Enter subcategory name"
                        value={newSubcategory.name}
                        onChange={(e) => setNewSubcategory({ ...newSubcategory, name: e.target.value })}
                      />
                    </div>
                    <Button
                      onClick={handleAddSubcategory}
                      className="w-full rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Subcategory
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {selectedCategory && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(categories[selectedCategory]?.subcategories || {}).map(([key, subcategory]) => (
                <Card key={key} className="rounded-lg border border-slate-200 bg-white">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-medium text-slate-800">{subcategory.name}</span>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-lg border-red-300 text-red-600 hover:bg-red-100"
                        onClick={() => handleDeleteSubcategory(selectedCategory, key)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="text-xs text-slate-600 mb-3 bg-slate-100 p-2 rounded border border-slate-200">
                      {subcategory.items?.length || 0} items
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full rounded-lg border-slate-300 text-slate-600 hover:bg-slate-100"
                      onClick={() => handleEditSubcategory(selectedCategory, key, subcategory)}
                    >
                      Edit Subcategory
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">Manage Items</h3>
            <div className="flex items-center space-x-3">
              <Select value={selectedCategory} onValueChange={handleCategoryChangeForItems}>
                <SelectTrigger className="w-40 rounded-lg border-blue-200 bg-blue-50">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(categories).map(([key, category]) => (
                    <SelectItem key={key} value={key}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedCategory && (
                <Select value={selectedSubcategory} onValueChange={setSelectedSubcategory}>
                  <SelectTrigger className="w-40 rounded-lg border-blue-200 bg-blue-50">
                    <SelectValue placeholder="Subcategory" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(categories[selectedCategory]?.subcategories || {}).map(([key, subcategory]) => (
                      <SelectItem key={key} value={key}>
                        {subcategory.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Dialog open={showAddItemDialog} onOpenChange={setShowAddItemDialog}>
                <DialogTrigger asChild>
                  <Button
                    className="rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
                    disabled={!selectedCategory || !selectedSubcategory}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Item
                  </Button>
                </DialogTrigger>
                <DialogContent className="rounded-lg border border-blue-200 bg-blue-50">
                  <DialogHeader>
                    <DialogTitle className="text-blue-800">Add New Item</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-blue-700">Item Name</Label>
                      <Input
                        className="rounded-lg border-blue-200 bg-white"
                        placeholder="Enter item name"
                        value={newItem.name}
                        onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label className="text-blue-700">Price</Label>
                      <Input
                        type="number"
                        className="rounded-lg border-blue-200 bg-white"
                        placeholder="Enter price"
                        value={newItem.price}
                        onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label className="text-blue-700">Stock</Label>
                      <Input
                        type="number"
                        className="rounded-lg border-blue-200 bg-white"
                        placeholder="Enter stock quantity"
                        value={newItem.stock}
                        onChange={(e) => setNewItem({ ...newItem, stock: e.target.value })}
                      />
                    </div>
                    <Button
                      onClick={handleAddItem}
                      className="w-full rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Item
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 w-4 h-4" />
              <Input
                placeholder="Search items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 rounded-lg border-blue-200 bg-blue-50"
              />
            </div>
          </div>

          <div className="max-h-96 overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {filteredItems.map((item) => (
                <Card key={item.id} className="rounded-lg border border-slate-200 bg-white">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm truncate text-slate-800">{item.name}</span>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-lg h-6 w-6 p-0 border-red-300 text-red-600 hover:bg-red-100"
                        onClick={() => handleDeleteItem(item.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="text-xs text-slate-600 mb-2 bg-slate-100 p-1 rounded border border-slate-200">
                      {item.categoryName} → {item.subcategoryName}
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-slate-700">Price: Rs {item.price}</span>
                      <span className="text-xs text-slate-700">Stock: {item.stock}</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full rounded-lg h-6 text-xs border-blue-300 text-blue-600 hover:bg-blue-100"
                      onClick={() => handleEditItem(item)}
                    >
                      Edit Item
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Item Dialog */}
      <Dialog open={showEditItemDialog} onOpenChange={setShowEditItemDialog}>
        <DialogContent className="rounded-lg border border-blue-200 bg-blue-50">
          <DialogHeader>
            <DialogTitle className="text-blue-800">Edit Item</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-blue-700">Item Name</Label>
              <Input
                className="rounded-lg border-blue-200 bg-white"
                placeholder="Enter item name"
                value={editItemData.name}
                onChange={(e) => setEditItemData({ ...editItemData, name: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-blue-700">Price</Label>
              <Input
                type="number"
                className="rounded-lg border-blue-200 bg-white"
                placeholder="Enter price"
                value={editItemData.price}
                onChange={(e) => setEditItemData({ ...editItemData, price: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-blue-700">Stock</Label>
              <Input
                type="number"
                className="rounded-lg border-blue-200 bg-white"
                placeholder="Enter stock quantity"
                value={editItemData.stock}
                onChange={(e) => setEditItemData({ ...editItemData, stock: e.target.value })}
              />
            </div>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowEditItemDialog(false)}
                className="flex-1 rounded-lg border-slate-300 text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEditItem}
                className="flex-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Category Dialog */}
      <Dialog open={showEditCategoryDialog} onOpenChange={setShowEditCategoryDialog}>
        <DialogContent className="rounded-lg border border-blue-200 bg-blue-50">
          <DialogHeader>
            <DialogTitle className="text-blue-800">Edit Category</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-blue-700">Category Name</Label>
              <Input
                className="rounded-lg border-blue-200 bg-white"
                placeholder="Enter category name"
                value={editCategoryData.name}
                onChange={(e) => setEditCategoryData({ ...editCategoryData, name: e.target.value })}
              />
            </div>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowEditCategoryDialog(false)}
                className="flex-1 rounded-lg border-slate-300 text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEditCategory}
                className="flex-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Subcategory Dialog */}
      <Dialog open={showEditSubcategoryDialog} onOpenChange={setShowEditSubcategoryDialog}>
        <DialogContent className="rounded-lg border border-blue-200 bg-blue-50">
          <DialogHeader>
            <DialogTitle className="text-blue-800">Edit Subcategory</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-blue-700">Subcategory Name</Label>
              <Input
                className="rounded-lg border-blue-200 bg-white"
                placeholder="Enter subcategory name"
                value={editSubcategoryData.name}
                onChange={(e) => setEditSubcategoryData({ ...editSubcategoryData, name: e.target.value })}
              />
            </div>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowEditSubcategoryDialog(false)}
                className="flex-1 rounded-lg border-slate-300 text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEditSubcategory}
                className="flex-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )

  const handleCategoryChangeForItems = (categoryKey) => {
    setSelectedCategory(categoryKey)
    setSelectedSubcategory("") // Reset subcategory when category changes
  }

  const getFilteredItems = () => {
    let items = []

    if (selectedCategory && selectedSubcategory) {
      // Get items from specific category and subcategory
      items = categories[selectedCategory]?.subcategories[selectedSubcategory]?.items || []
      // Add category and subcategory names to each item
      items = items.map((item) => ({
        ...item,
        categoryName: categories[selectedCategory]?.name,
        subcategoryName: categories[selectedCategory]?.subcategories[selectedSubcategory]?.name,
      }))
    } else if (selectedCategory) {
      // Get all items from selected category
      Object.entries(categories[selectedCategory]?.subcategories || {}).forEach(([subKey, subcategory]) => {
        const categoryItems = subcategory.items.map((item) => ({
          ...item,
          categoryName: categories[selectedCategory]?.name,
          subcategoryName: subcategory.name,
        }))
        items = [...items, ...categoryItems]
      })
    } else {
      // Get all items if no category selected
      items = getAllItems()
    }

    // Apply search filter
    if (searchTerm) {
      items = items.filter((item) => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
    }

    return items
  }

  const filteredItems = getFilteredItems()

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Admin Sidebar */}
      <div className="w-64 bg-white shadow-lg border-r border-slate-200 relative">
        <div className="p-4 border-b border-slate-200">
          <div className="flex items-center space-x-3">
            <div className="flex flex-col items-center">
              <span className="text-xs text-slate-500 mb-1">Powered by</span>
              <div className="w-16 h-16 rounded-lg flex items-center justify-center overflow-hidden">
                <img src="/images/trust-nexus-logo.png" alt="Logo" className="w-full h-full object-contain" />
              </div>
            </div>
            <div>
              <h2 className="font-bold text-slate-800">Remidix</h2>
              <p className="text-xs text-slate-500">Admin Panel</p>
            </div>
          </div>
        </div>

        <nav className="p-4 pb-20">
          <div className="space-y-2">
            {sidebarItems.map((item) => (
              <Button
                key={item.id}
                variant={activeSection === item.id ? "default" : "ghost"}
                className={`w-full justify-start rounded-lg ${
                  activeSection === item.id
                    ? "bg-blue-600 text-white hover:bg-blue-700"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-700"
                }`}
                onClick={() => setActiveSection(item.id)}
              >
                <item.icon className="w-4 h-4 mr-3" />
                {item.label}
              </Button>
            ))}
          </div>
        </nav>

        <div className="absolute bottom-2 left-2 right-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-center rounded-lg px-2 py-1 h-8 border-slate-300 text-slate-600 hover:bg-slate-50"
            onClick={onLogout}
          >
            <LogOut className="w-3 h-3 mr-1" />
            <span className="text-xs">Logout</span>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 overflow-y-auto">
        {activeSection === "dashboard" && renderDashboard()}
        {activeSection === "inventory" && renderInventory()}
        {activeSection === "sales" && renderSales()}
        {activeSection === "edit" && renderEdit()}
      </div>
    </div>
  )
}
