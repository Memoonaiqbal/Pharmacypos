"use client"

import { useState } from "react"
import { Search, RotateCcw, Save, Printer, Plus, Minus, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function BillingPanel({
  billItems,
  removeFromBill,
  updateBillQuantity,
  clearBill,
  setShowSearch,
  setShowReturns,
  setShowAdmin,
  isAuthenticated,
  setIsAuthenticated,
}) {
  const [adminCredentials, setAdminCredentials] = useState({ username: "", password: "" })

  // Calculate total
  const calculateTotal = () => {
    return billItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2)
  }

  // Admin authentication
  const handleAdminLogin = () => {
    if (adminCredentials.username === "admin" && adminCredentials.password === "admin123") {
      setIsAuthenticated(true)
      setShowAdmin(true)
    } else {
      alert("Invalid credentials")
    }
  }

  // Print bill
  const printBill = () => {
    const printContent = `
      REMIDIX PHARMACY
  ${new Date().toLocaleString()}

================================
Item                 Qty   Price
================================
${billItems
  .map((item) => {
    const itemName = item.name.length > 20 ? item.name.substring(0, 17) + "..." : item.name
    const qtyStr = item.quantity.toString()
    const priceStr = `Rs ${(item.price * item.quantity).toFixed(2)}`

    return `${itemName.padEnd(20)} ${qtyStr.padStart(3)} ${priceStr.padStart(8)}`
  })
  .join("\n")}
================================
TOTAL: Rs ${calculateTotal()}
================================

Thank you for your purchase!
Visit us again soon.

--------------------------------
      Powered by Trust Nexus
--------------------------------
`

    const printWindow = window.open("", "_blank")
    printWindow.document.write(`
  <html>
    <head>
      <title>Pharmacy Bill</title>
      <style>
        body { 
          font-family: 'Courier New', monospace; 
          font-size: 12px; 
          line-height: 1.3; 
          margin: 20px;
          text-align: center;
        }
        .bill-content {
          white-space: pre;
          display: inline-block;
          text-align: left;
        }
      </style>
    </head>
    <body>
      <div class="bill-content">${printContent}</div>
    </body>
  </html>
`)
    printWindow.print()
  }

  return (
    <div className="w-96 bg-white shadow-lg border-l border-slate-200 flex flex-col">
      {/* Top Navigation */}
      <header className="bg-white shadow-sm border-b border-slate-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex flex-col items-center">
              <span className="text-xs text-slate-500 mb-1">Powered by</span>
              <div className="w-16 h-16 rounded-lg flex items-center justify-center overflow-hidden">
                <img src="/images/trust-nexus-logo.png" alt="Logo" className="w-full h-full object-contain" />
              </div>
            </div>
            <h1 className="text-lg font-bold text-slate-800">Remidix Pharmacy</h1>
          </div>

          <div className="flex items-center space-x-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full border-slate-300 text-slate-600 hover:bg-slate-50"
                >
                  <User className="w-3 h-3" />
                </Button>
              </DialogTrigger>
              <DialogContent className="rounded-lg border border-slate-200 bg-slate-50">
                <DialogHeader>
                  <DialogTitle className="text-slate-800">Admin Login</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="username" className="text-slate-700">
                      Username
                    </Label>
                    <Input
                      id="username"
                      value={adminCredentials.username}
                      onChange={(e) => setAdminCredentials({ ...adminCredentials, username: e.target.value })}
                      className="rounded-lg border-slate-200 bg-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="password" className="text-slate-700">
                      Password
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      value={adminCredentials.password}
                      onChange={(e) => setAdminCredentials({ ...adminCredentials, password: e.target.value })}
                      className="rounded-lg border-slate-200 bg-white"
                    />
                  </div>
                  <Button
                    onClick={handleAdminLogin}
                    className="w-full rounded-lg bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Login
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      {/* Billing Section */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-800">Receipt</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={clearBill}
            className="rounded-lg border-red-300 text-red-600 hover:bg-red-50"
          >
            Clear
          </Button>
        </div>

        <div className="flex space-x-2 mb-4">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 rounded-lg border-slate-300 text-slate-600 hover:bg-slate-50"
            onClick={() => setShowSearch(true)}
          >
            <Search className="w-4 h-4 mr-2" />
            Search
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="flex-1 rounded-lg border-slate-300 text-slate-600 hover:bg-slate-50"
            onClick={() => setShowReturns(true)}
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Returns
          </Button>
        </div>

        {/* Bill Header */}
        <div className="bg-slate-50 rounded-lg p-2 border border-slate-200">
          <div className="grid grid-cols-12 gap-2 text-xs font-medium text-slate-700">
            <div className="col-span-6">Item Name</div>
            <div className="col-span-3 text-center">Quantity</div>
            <div className="col-span-3 text-right">Price</div>
          </div>
        </div>
      </div>

      {/* Bill Items */}
      <div className="flex-1 overflow-y-auto px-4">
        <div className="space-y-2">
          {billItems.map((item) => (
            <Card key={item.id} className="rounded-lg border border-blue-200 bg-blue-50">
              <CardContent className="p-2">
                <div className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-6">
                    <h4 className="font-medium text-blue-800 text-xs leading-tight">{item.name}</h4>
                    <p className="text-xs text-blue-600">Rs {item.price} each</p>
                  </div>
                  <div className="col-span-3 flex items-center justify-center space-x-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => updateBillQuantity(item.id, item.quantity - 1)}
                      className="w-5 h-5 rounded-full p-0 border-red-300 text-red-600 hover:bg-red-100"
                    >
                      <Minus className="w-2 h-2" />
                    </Button>
                    <span className="w-6 text-center font-medium text-xs text-blue-800">{item.quantity}</span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => updateBillQuantity(item.id, item.quantity + 1)}
                      className="w-5 h-5 rounded-full p-0 border-blue-300 text-blue-600 hover:bg-blue-100"
                    >
                      <Plus className="w-2 h-2" />
                    </Button>
                  </div>
                  <div className="col-span-3 text-right">
                    <span className="font-medium text-blue-700 text-xs">
                      Rs {(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Bill Total and Actions */}
      <div className="p-4 border-t border-slate-200">
        <div className="flex justify-between items-center mb-4">
          <span className="text-lg font-semibold text-slate-800">Total:</span>
          <span className="text-2xl font-bold text-blue-700">Rs {calculateTotal()}</span>
        </div>

        <div className="flex space-x-3">
          <Button className="flex-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white">
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
          <Button
            onClick={printBill}
            variant="outline"
            className="flex-1 rounded-lg border-green-300 text-green-600 hover:bg-green-50"
          >
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
        </div>
      </div>
    </div>
  )
}
