"use client"

import { useState } from "react"
import Sidebar from "@/components/Sidebar"
import ItemsDisplay from "@/components/ItemsDisplay"
import BillingPanel from "@/components/BillingPanel"
import AdminModule from "@/components/AdminModule"
import SearchDialog from "@/components/SearchDialog"
import ReturnsDialog from "@/components/ReturnsDialog"
import { medicineData } from "@/data/medicineData"

export default function PharmacyPOS() {
  const [categories, setCategories] = useState(medicineData)
  const [selectedCategory, setSelectedCategory] = useState("medicines")
  const [selectedSubcategory, setSelectedSubcategory] = useState("painRelief")
  const [billItems, setBillItems] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showAdmin, setShowAdmin] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [showReturns, setShowReturns] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)

  // Get all items for search
  const getAllItems = () => {
    const allItems = []
    Object.values(categories).forEach((category) => {
      Object.values(category.subcategories).forEach((subcategory) => {
        subcategory.items.forEach((item) => {
          allItems.push({
            ...item,
            categoryName: category.name,
            subcategoryName: subcategory.name,
          })
        })
      })
    })
    return allItems
  }

  // Add item to bill
  const addToBill = (item) => {
    const existingItem = billItems.find((billItem) => billItem.id === item.id)
    if (existingItem) {
      setBillItems(
        billItems.map((billItem) =>
          billItem.id === item.id ? { ...billItem, quantity: billItem.quantity + 1 } : billItem,
        ),
      )
    } else {
      setBillItems([...billItems, { ...item, quantity: 1 }])
    }
  }

  // Remove item from bill
  const removeFromBill = (itemId) => {
    setBillItems(billItems.filter((item) => item.id !== itemId))
  }

  // Update item quantity in bill
  const updateBillQuantity = (itemId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromBill(itemId)
    } else {
      setBillItems(billItems.map((item) => (item.id === itemId ? { ...item, quantity: newQuantity } : item)))
    }
  }

  // Clear all bill items
  const clearBill = () => {
    setBillItems([])
  }

  // Update inventory
  const updateInventory = (itemId, newStock) => {
    setCategories((prevCategories) => {
      const newCategories = { ...prevCategories }
      Object.keys(newCategories).forEach((catKey) => {
        Object.keys(newCategories[catKey].subcategories).forEach((subKey) => {
          newCategories[catKey].subcategories[subKey].items = newCategories[catKey].subcategories[subKey].items.map(
            (item) => (item.id === itemId ? { ...item, stock: newStock } : item),
          )
        })
      })
      return newCategories
    })
  }

  // Get current items to display
  const getCurrentItems = () => {
    return categories[selectedCategory]?.subcategories[selectedSubcategory]?.items || []
  }

  // Handle admin logout
  const handleAdminLogout = () => {
    setShowAdmin(false)
    setIsAuthenticated(false)
  }

  // Show admin module if authenticated
  if (showAdmin && isAuthenticated) {
    return (
      <AdminModule
        categories={categories}
        setCategories={setCategories}
        updateInventory={updateInventory}
        getAllItems={getAllItems}
        onLogout={handleAdminLogout}
      />
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="flex h-screen">
        {/* Sidebar */}
        <Sidebar
          categories={categories}
          selectedCategory={selectedCategory}
          selectedSubcategory={selectedSubcategory}
          setSelectedCategory={setSelectedCategory}
          setSelectedSubcategory={setSelectedSubcategory}
          setSearchTerm={setSearchTerm}
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          searchTerm={searchTerm} // Add this line
        />

        {/* Main Content */}
        <div className="flex-1 flex">
          {/* Items Display */}
          <ItemsDisplay items={getCurrentItems()} searchTerm={searchTerm} addToBill={addToBill} />

          {/* Billing Panel */}
          <BillingPanel
            billItems={billItems}
            removeFromBill={removeFromBill}
            updateBillQuantity={updateBillQuantity}
            clearBill={clearBill}
            setShowSearch={setShowSearch}
            setShowReturns={setShowReturns}
            setShowAdmin={setShowAdmin}
            isAuthenticated={isAuthenticated}
            setIsAuthenticated={setIsAuthenticated}
          />
        </div>
      </div>

      {/* Search Dialog */}
      <SearchDialog open={showSearch} onOpenChange={setShowSearch} categories={categories} addToBill={addToBill} />

      {/* Returns Dialog */}
      <ReturnsDialog
        open={showReturns}
        onOpenChange={setShowReturns}
        categories={categories}
        updateInventory={updateInventory}
      />
    </div>
  )
}
